Anybody Variable Font
=====================

This download contains Anybody as both variable fonts and static fonts.

Anybody is a variable font with these axes:
  wdth
  wght

This means all the styles are contained in these files:
  Anybody/Anybody-VariableFont_wdth,wght.ttf
  Anybody/Anybody-Italic-VariableFont_wdth,wght.ttf

If your app fully supports variable fonts, you can now pick intermediate styles
that aren’t available as static fonts. Not all apps support variable fonts, and
in those cases you can use the static font files for Anybody:
  Anybody/static/Anybody_UltraCondensed-Thin.ttf
  Anybody/static/Anybody_UltraCondensed-ExtraLight.ttf
  Anybody/static/Anybody_UltraCondensed-Light.ttf
  Anybody/static/Anybody_UltraCondensed-Regular.ttf
  Anybody/static/Anybody_UltraCondensed-Medium.ttf
  Anybody/static/Anybody_UltraCondensed-SemiBold.ttf
  Anybody/static/Anybody_UltraCondensed-Bold.ttf
  Anybody/static/Anybody_UltraCondensed-ExtraBold.ttf
  Anybody/static/Anybody_UltraCondensed-Black.ttf
  Anybody/static/Anybody_ExtraCondensed-Thin.ttf
  Anybody/static/Anybody_ExtraCondensed-ExtraLight.ttf
  Anybody/static/Anybody_ExtraCondensed-Light.ttf
  Anybody/static/Anybody_ExtraCondensed-Regular.ttf
  Anybody/static/Anybody_ExtraCondensed-Medium.ttf
  Anybody/static/Anybody_ExtraCondensed-SemiBold.ttf
  Anybody/static/Anybody_ExtraCondensed-Bold.ttf
  Anybody/static/Anybody_ExtraCondensed-ExtraBold.ttf
  Anybody/static/Anybody_ExtraCondensed-Black.ttf
  Anybody/static/Anybody_Condensed-Thin.ttf
  Anybody/static/Anybody_Condensed-ExtraLight.ttf
  Anybody/static/Anybody_Condensed-Light.ttf
  Anybody/static/Anybody_Condensed-Regular.ttf
  Anybody/static/Anybody_Condensed-Medium.ttf
  Anybody/static/Anybody_Condensed-SemiBold.ttf
  Anybody/static/Anybody_Condensed-Bold.ttf
  Anybody/static/Anybody_Condensed-ExtraBold.ttf
  Anybody/static/Anybody_Condensed-Black.ttf
  Anybody/static/Anybody_SemiCondensed-Thin.ttf
  Anybody/static/Anybody_SemiCondensed-ExtraLight.ttf
  Anybody/static/Anybody_SemiCondensed-Light.ttf
  Anybody/static/Anybody_SemiCondensed-Regular.ttf
  Anybody/static/Anybody_SemiCondensed-Medium.ttf
  Anybody/static/Anybody_SemiCondensed-SemiBold.ttf
  Anybody/static/Anybody_SemiCondensed-Bold.ttf
  Anybody/static/Anybody_SemiCondensed-ExtraBold.ttf
  Anybody/static/Anybody_SemiCondensed-Black.ttf
  Anybody/static/Anybody-Thin.ttf
  Anybody/static/Anybody-ExtraLight.ttf
  Anybody/static/Anybody-Light.ttf
  Anybody/static/Anybody-Regular.ttf
  Anybody/static/Anybody-Medium.ttf
  Anybody/static/Anybody-SemiBold.ttf
  Anybody/static/Anybody-Bold.ttf
  Anybody/static/Anybody-ExtraBold.ttf
  Anybody/static/Anybody-Black.ttf
  Anybody/static/Anybody_SemiExpanded-Thin.ttf
  Anybody/static/Anybody_SemiExpanded-ExtraLight.ttf
  Anybody/static/Anybody_SemiExpanded-Light.ttf
  Anybody/static/Anybody_SemiExpanded-Regular.ttf
  Anybody/static/Anybody_SemiExpanded-Medium.ttf
  Anybody/static/Anybody_SemiExpanded-SemiBold.ttf
  Anybody/static/Anybody_SemiExpanded-Bold.ttf
  Anybody/static/Anybody_SemiExpanded-ExtraBold.ttf
  Anybody/static/Anybody_SemiExpanded-Black.ttf
  Anybody/static/Anybody_Expanded-Thin.ttf
  Anybody/static/Anybody_Expanded-ExtraLight.ttf
  Anybody/static/Anybody_Expanded-Light.ttf
  Anybody/static/Anybody_Expanded-Regular.ttf
  Anybody/static/Anybody_Expanded-Medium.ttf
  Anybody/static/Anybody_Expanded-SemiBold.ttf
  Anybody/static/Anybody_Expanded-Bold.ttf
  Anybody/static/Anybody_Expanded-ExtraBold.ttf
  Anybody/static/Anybody_Expanded-Black.ttf
  Anybody/static/Anybody_ExtraExpanded-Thin.ttf
  Anybody/static/Anybody_ExtraExpanded-ExtraLight.ttf
  Anybody/static/Anybody_ExtraExpanded-Light.ttf
  Anybody/static/Anybody_ExtraExpanded-Regular.ttf
  Anybody/static/Anybody_ExtraExpanded-Medium.ttf
  Anybody/static/Anybody_ExtraExpanded-SemiBold.ttf
  Anybody/static/Anybody_ExtraExpanded-Bold.ttf
  Anybody/static/Anybody_ExtraExpanded-ExtraBold.ttf
  Anybody/static/Anybody_ExtraExpanded-Black.ttf
  Anybody/static/Anybody_UltraCondensed-ThinItalic.ttf
  Anybody/static/Anybody_UltraCondensed-ExtraLightItalic.ttf
  Anybody/static/Anybody_UltraCondensed-LightItalic.ttf
  Anybody/static/Anybody_UltraCondensed-Italic.ttf
  Anybody/static/Anybody_UltraCondensed-MediumItalic.ttf
  Anybody/static/Anybody_UltraCondensed-SemiBoldItalic.ttf
  Anybody/static/Anybody_UltraCondensed-BoldItalic.ttf
  Anybody/static/Anybody_UltraCondensed-ExtraBoldItalic.ttf
  Anybody/static/Anybody_UltraCondensed-BlackItalic.ttf
  Anybody/static/Anybody_ExtraCondensed-ThinItalic.ttf
  Anybody/static/Anybody_ExtraCondensed-ExtraLightItalic.ttf
  Anybody/static/Anybody_ExtraCondensed-LightItalic.ttf
  Anybody/static/Anybody_ExtraCondensed-Italic.ttf
  Anybody/static/Anybody_ExtraCondensed-MediumItalic.ttf
  Anybody/static/Anybody_ExtraCondensed-SemiBoldItalic.ttf
  Anybody/static/Anybody_ExtraCondensed-BoldItalic.ttf
  Anybody/static/Anybody_ExtraCondensed-ExtraBoldItalic.ttf
  Anybody/static/Anybody_ExtraCondensed-BlackItalic.ttf
  Anybody/static/Anybody_Condensed-ThinItalic.ttf
  Anybody/static/Anybody_Condensed-ExtraLightItalic.ttf
  Anybody/static/Anybody_Condensed-LightItalic.ttf
  Anybody/static/Anybody_Condensed-Italic.ttf
  Anybody/static/Anybody_Condensed-MediumItalic.ttf
  Anybody/static/Anybody_Condensed-SemiBoldItalic.ttf
  Anybody/static/Anybody_Condensed-BoldItalic.ttf
  Anybody/static/Anybody_Condensed-ExtraBoldItalic.ttf
  Anybody/static/Anybody_Condensed-BlackItalic.ttf
  Anybody/static/Anybody_SemiCondensed-ThinItalic.ttf
  Anybody/static/Anybody_SemiCondensed-ExtraLightItalic.ttf
  Anybody/static/Anybody_SemiCondensed-LightItalic.ttf
  Anybody/static/Anybody_SemiCondensed-Italic.ttf
  Anybody/static/Anybody_SemiCondensed-MediumItalic.ttf
  Anybody/static/Anybody_SemiCondensed-SemiBoldItalic.ttf
  Anybody/static/Anybody_SemiCondensed-BoldItalic.ttf
  Anybody/static/Anybody_SemiCondensed-ExtraBoldItalic.ttf
  Anybody/static/Anybody_SemiCondensed-BlackItalic.ttf
  Anybody/static/Anybody-ThinItalic.ttf
  Anybody/static/Anybody-ExtraLightItalic.ttf
  Anybody/static/Anybody-LightItalic.ttf
  Anybody/static/Anybody-Italic.ttf
  Anybody/static/Anybody-MediumItalic.ttf
  Anybody/static/Anybody-SemiBoldItalic.ttf
  Anybody/static/Anybody-BoldItalic.ttf
  Anybody/static/Anybody-ExtraBoldItalic.ttf
  Anybody/static/Anybody-BlackItalic.ttf
  Anybody/static/Anybody_SemiExpanded-ThinItalic.ttf
  Anybody/static/Anybody_SemiExpanded-ExtraLightItalic.ttf
  Anybody/static/Anybody_SemiExpanded-LightItalic.ttf
  Anybody/static/Anybody_SemiExpanded-Italic.ttf
  Anybody/static/Anybody_SemiExpanded-MediumItalic.ttf
  Anybody/static/Anybody_SemiExpanded-SemiBoldItalic.ttf
  Anybody/static/Anybody_SemiExpanded-BoldItalic.ttf
  Anybody/static/Anybody_SemiExpanded-ExtraBoldItalic.ttf
  Anybody/static/Anybody_SemiExpanded-BlackItalic.ttf
  Anybody/static/Anybody_Expanded-ThinItalic.ttf
  Anybody/static/Anybody_Expanded-ExtraLightItalic.ttf
  Anybody/static/Anybody_Expanded-LightItalic.ttf
  Anybody/static/Anybody_Expanded-Italic.ttf
  Anybody/static/Anybody_Expanded-MediumItalic.ttf
  Anybody/static/Anybody_Expanded-SemiBoldItalic.ttf
  Anybody/static/Anybody_Expanded-BoldItalic.ttf
  Anybody/static/Anybody_Expanded-ExtraBoldItalic.ttf
  Anybody/static/Anybody_Expanded-BlackItalic.ttf
  Anybody/static/Anybody_ExtraExpanded-ThinItalic.ttf
  Anybody/static/Anybody_ExtraExpanded-ExtraLightItalic.ttf
  Anybody/static/Anybody_ExtraExpanded-LightItalic.ttf
  Anybody/static/Anybody_ExtraExpanded-Italic.ttf
  Anybody/static/Anybody_ExtraExpanded-MediumItalic.ttf
  Anybody/static/Anybody_ExtraExpanded-SemiBoldItalic.ttf
  Anybody/static/Anybody_ExtraExpanded-BoldItalic.ttf
  Anybody/static/Anybody_ExtraExpanded-ExtraBoldItalic.ttf
  Anybody/static/Anybody_ExtraExpanded-BlackItalic.ttf

Get started
-----------

1. Install the font files you want to use

2. Use your app's font picker to view the font family and all the
available styles

Learn more about variable fonts
-------------------------------

  https://developers.google.com/web/fundamentals/design-and-ux/typography/variable-fonts
  https://variablefonts.typenetwork.com
  https://medium.com/variable-fonts

In desktop apps

  https://theblog.adobe.com/can-variable-fonts-illustrator-cc
  https://helpx.adobe.com/nz/photoshop/using/fonts.html#variable_fonts

Online

  https://developers.google.com/fonts/docs/getting_started
  https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Fonts/Variable_Fonts_Guide
  https://developer.microsoft.com/en-us/microsoft-edge/testdrive/demos/variable-fonts

Installing fonts

  MacOS: https://support.apple.com/en-us/HT201749
  Linux: https://www.google.com/search?q=how+to+install+a+font+on+gnu%2Blinux
  Windows: https://support.microsoft.com/en-us/help/314960/how-to-install-or-remove-a-font-in-windows

Android Apps

  https://developers.google.com/fonts/docs/android
  https://developer.android.com/guide/topics/ui/look-and-feel/downloadable-fonts

License
-------
Please read the full license text (OFL.txt) to understand the permissions,
restrictions and requirements for usage, redistribution, and modification.

You can use them in your products & projects – print or digital,
commercial or otherwise.

This isn't legal advice, please consider consulting a lawyer and see the full
license for all details.
